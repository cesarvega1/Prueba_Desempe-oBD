-- =====================================================================
-- PROYECTO: bd_Cesar_Vega_Esthercita
-- Sistema de Distribución de Productos Ecológicos
-- Autor: Cesar Vega
-- =====================================================================
-- Este archivo agrupa en un solo script SQL las siguientes secciones,
-- tal como se solicitó:
--   1. Script DDL (creación de la base de datos y tablas)
--   2. Scripts de carga (inserción de datos iniciales)
--   3. Scripts DML (operaciones de manipulación de datos: UPDATE/DELETE)
--   4. Consultas SQL (reportes solicitados)
--   5. Vista de rendimiento comercial por ciudad
-- =====================================================================


-- =====================================================================
-- 1. SCRIPT DDL
-- =====================================================================

DROP DATABASE IF EXISTS bd_Cesar_Vega_Esthercita;
CREATE DATABASE bd_Cesar_Vega_Esthercita;
USE bd_Cesar_Vega_Esthercita;

CREATE TABLE eco_cities (
    eco_city_id INT PRIMARY KEY,
    eco_city_name VARCHAR(50) NOT NULL
);

CREATE TABLE eco_categories (
    eco_category_id INT PRIMARY KEY,
    eco_category_name VARCHAR(50) NOT NULL
);

CREATE TABLE eco_distribution_centers (
    eco_center_id VARCHAR(10) PRIMARY KEY,
    eco_center_name VARCHAR(50) NOT NULL
);

CREATE TABLE eco_clients (
    eco_client_id INT PRIMARY KEY,
    eco_client_name VARCHAR(100) NOT NULL,
    eco_city_id INT NOT NULL,
    FOREIGN KEY (eco_city_id) REFERENCES eco_cities(eco_city_id)
);

CREATE TABLE eco_products (
    eco_product_id VARCHAR(10) PRIMARY KEY,
    eco_product_name VARCHAR(100) NOT NULL,
    eco_category_id INT NOT NULL,
    eco_unit_price DECIMAL(10, 2) NOT NULL,
    eco_stock INT NOT NULL,
    FOREIGN KEY (eco_category_id) REFERENCES eco_categories(eco_category_id)
);

CREATE TABLE eco_orders (
    eco_order_id VARCHAR(10) PRIMARY KEY,
    eco_client_id INT NOT NULL,
    eco_product_id VARCHAR(10) NOT NULL,
    eco_center_id VARCHAR(10) NOT NULL,
    eco_order_date DATE NOT NULL,
    eco_quantity INT NOT NULL,
    FOREIGN KEY (eco_client_id) REFERENCES eco_clients(eco_client_id),
    FOREIGN KEY (eco_product_id) REFERENCES eco_products(eco_product_id),
    FOREIGN KEY (eco_center_id) REFERENCES eco_distribution_centers(eco_center_id)
);


-- =====================================================================
-- 2. SCRIPTS DE CARGA (datos iniciales)
-- =====================================================================

INSERT INTO eco_cities (eco_city_id, eco_city_name) VALUES
(1, 'Bogotá'),
(2, 'Medellín'),
(3, 'Cali'),
(4, 'Barranquilla'),
(5, 'Cartagena'),
(6, 'Bucaramanga'),
(7, 'Pereira'),
(8, 'Manizales'),
(9, 'Cúcuta');

INSERT INTO eco_categories (eco_category_id, eco_category_name) VALUES
(1, 'Fruits'),
(2, 'Dairy'),
(3, 'Meat'),
(4, 'Grains'),
(5, 'Oils'),
(6, 'Vegetables');

INSERT INTO eco_distribution_centers (eco_center_id, eco_center_name) VALUES
('CD01', 'North Center'),
('CD02', 'West Center'),
('CD03', 'South Hub'),
('CD04', 'Coast DC'),
('CD05', 'East Hub'),
('CD06', 'Coffee DC');

INSERT INTO eco_clients (eco_client_id, eco_client_name, eco_city_id) VALUES
(1, 'SuperMax', 1),
(2, 'FreshMart', 2),
(3, 'MiniShop', 3),
(4, 'SuperMax', 4),
(5, 'EcoStore', 5),
(6, 'MarketOne', 6),
(7, 'RetailCo', 7),
(8, 'FoodPlus', 8),
(9, 'GreenBuy', 1),
(10, 'QuickFood', 9);

INSERT INTO eco_products (eco_product_id, eco_product_name, eco_category_id, eco_unit_price, eco_stock) VALUES
('P01', 'Gala Apple', 1, 2.50, 100),
('P02', 'Banana', 1, 1.20, 180),
('P03', 'Whole Milk 1L', 2, 3.80, 60),
('P04', 'Chicken Breast', 3, 6.50, 70),
('P05', 'Rice 1kg', 4, 2.00, 200),
('P06', 'Extra Virgin Olive Oil', 5, 8.90, 40),
('P07', 'Eggs x12', 2, 4.20, 90),
('P08', 'Tomato', 6, 1.80, 120),
('P09', 'Iceberg Lettuce', 6, 1.10, 50),
('P10', 'Spaghetti', 4, 2.30, 140);

INSERT INTO eco_orders (eco_order_id, eco_client_id, eco_product_id, eco_center_id, eco_order_date, eco_quantity) VALUES
('O1001', 1, 'P01', 'CD01', '2026-05-01', 10),
('O1002', 1, 'P01', 'CD01', '2026-05-02', 5),
('O1003', 2, 'P02', 'CD02', '2026-05-02', 20),
('O1004', 2, 'P02', 'CD02', '2026-05-03', 15),
('O1005', 3, 'P03', 'CD03', '2026-05-04', 12),
('O1006', 3, 'P03', 'CD03', '2026-05-05', 8),
('O1007', 4, 'P04', 'CD04', '2026-05-06', 25),
('O1008', 4, 'P04', 'CD04', '2026-05-07', 10),
('O1009', 5, 'P05', 'CD04', '2026-05-08', 30),
('O1010', 5, 'P05', 'CD04', '2026-05-09', 18),
('O1011', 6, 'P06', 'CD05', '2026-05-10', 6),
('O1012', 6, 'P06', 'CD05', '2026-05-11', 4),
('O1013', 7, 'P07', 'CD06', '2026-05-12', 14),
('O1014', 7, 'P07', 'CD06', '2026-05-13', 9),
('O1015', 8, 'P08', 'CD06', '2026-05-14', 22),
('O1016', 8, 'P08', 'CD06', '2026-05-15', 16),
('O1017', 9, 'P09', 'CD01', '2026-05-16', 11),
('O1018', 9, 'P09', 'CD01', '2026-05-17', 7),
('O1019', 10, 'P10', 'CD05', '2026-05-18', 19),
('O1020', 10, 'P10', 'CD05', '2026-05-19', 13);


-- =====================================================================
-- 3. SCRIPTS DML (manipulación adicional de datos)
-- =====================================================================

-- Ejemplo de actualización: descuento de stock tras un nuevo pedido manual
UPDATE eco_products
SET eco_stock = eco_stock - 5
WHERE eco_product_id = 'P01';

-- Ejemplo de inserción de un nuevo pedido (simula operación diaria)
INSERT INTO eco_orders (eco_order_id, eco_client_id, eco_product_id, eco_center_id, eco_order_date, eco_quantity)
VALUES ('O1021', 1, 'P01', 'CD01', '2026-05-20', 5);

-- Ejemplo de eliminación de un registro (pedido cancelado)
-- DELETE FROM eco_orders WHERE eco_order_id = 'O1021';


-- =====================================================================
-- 4. CONSULTAS SQL
-- =====================================================================

-- Inventario disponible por producto
SELECT
    eco_product_id AS product_code,
    eco_product_name AS product_name,
    eco_stock AS available_stock
FROM eco_products
ORDER BY eco_stock DESC;

-- Historial de pedidos por ciudad
SELECT
    ci.eco_city_name AS city_name,
    o.eco_order_id AS order_id,
    o.eco_order_date AS order_date,
    cl.eco_client_name AS client_name,
    p.eco_product_name AS product_name,
    o.eco_quantity AS quantity_ordered,
    p.eco_unit_price AS unit_price,
    (o.eco_quantity * p.eco_unit_price) AS order_total
FROM eco_orders o
JOIN eco_clients cl ON o.eco_client_id = cl.eco_client_id
JOIN eco_cities ci ON cl.eco_city_id = ci.eco_city_id
JOIN eco_products p ON o.eco_product_id = p.eco_product_id
ORDER BY ci.eco_city_name ASC, o.eco_order_date DESC;

-- Total vendido por categoría
SELECT
    c.eco_category_name AS category_name,
    SUM(o.eco_quantity) AS total_units_sold,
    SUM(o.eco_quantity * p.eco_unit_price) AS total_revenue
FROM eco_orders o
JOIN eco_products p ON o.eco_product_id = p.eco_product_id
JOIN eco_categories c ON p.eco_category_id = c.eco_category_id
GROUP BY c.eco_category_id, c.eco_category_name
ORDER BY total_revenue DESC;

-- Clientes con mayor número de pedidos
SELECT
    c.eco_client_id AS client_code,
    c.eco_client_name AS client_name,
    COUNT(o.eco_order_id) AS total_orders_placed,
    SUM(o.eco_quantity) AS total_units_bought
FROM eco_clients c
JOIN eco_orders o ON c.eco_client_id = o.eco_client_id
GROUP BY c.eco_client_id, c.eco_client_name
ORDER BY total_orders_placed DESC, total_units_bought DESC;

-- Productos con menor inventario
SELECT
    eco_product_id AS product_code,
    eco_product_name AS product_name,
    eco_stock AS available_stock
FROM eco_products
ORDER BY eco_stock ASC;

-- Valor económico del inventario por centro de distribución
SELECT
    dc.eco_center_id AS center_code,
    dc.eco_center_name AS distribution_center,
    SUM(p.eco_stock) AS total_items_in_stock,
    SUM(p.eco_stock * p.eco_unit_price) AS total_inventory_value
FROM eco_products p
JOIN eco_orders o ON p.eco_product_id = o.eco_product_id
JOIN eco_distribution_centers dc ON o.eco_center_id = dc.eco_center_id
GROUP BY dc.eco_center_id, dc.eco_center_name
ORDER BY total_inventory_value DESC;


-- =====================================================================
-- 5. VISTA: Rendimiento comercial por ciudad
-- =====================================================================

CREATE OR REPLACE VIEW eco_v_city_commercial_performance AS
SELECT
    ci.eco_city_name AS city_name,
    COUNT(DISTINCT o.eco_order_id) AS total_orders_placed,
    SUM(o.eco_quantity) AS total_units_sold,
    SUM(o.eco_quantity * p.eco_unit_price) AS total_revenue_usd,
    ROUND(AVG(o.eco_quantity * p.eco_unit_price), 2) AS average_ticket_usd
FROM eco_cities ci
JOIN eco_clients cl ON ci.eco_city_id = cl.eco_city_id
JOIN eco_orders o ON cl.eco_client_id = o.eco_client_id
JOIN eco_products p ON o.eco_product_id = p.eco_product_id
GROUP BY ci.eco_city_id, ci.eco_city_name;

SELECT * FROM eco_v_city_commercial_performance ORDER BY total_revenue_usd DESC;
